<html>
<head>

</head>
<body>

<form>
    <input type="text" size="30" onkeyup="showResult(this.value)">
    <div id="livesearch"></div>
</form>

</body>
</html>